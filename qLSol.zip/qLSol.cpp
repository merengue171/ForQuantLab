/*
 *Source code for Quantlab solution
 *
 *Created on  : Jan 7, 2021
 *Author      : Cheng Cheng
 *Email       : cchengster@gmail.com
 *Time spent  : 1.5 hours
 */


#include <cstddef>
#include <string>
#include <fstream>
#include <vector>
#include <stdexcept>
#include <sstream>
#include <map>
#include <math.h>

using namespace std;

//function for read input and fill the output map
void readInput(std::fstream* fin, std::map<string, std::vector<unsigned long>*>* output_map){
  
  std::vector<string> csv_row;
  std::string tmp,line, word;
  
  while (!fin->eof()){
    csv_row.clear();
    std::getline(*fin, line);
    std::stringstream ss(line);

    //extract each column
    while (std::getline(ss, word, ',')){
      csv_row.push_back(word);
    }
    unsigned long time_stamp=std::stoul(csv_row[0]);
    string stock_symbol=csv_row[1];
    int share=std::stoi(csv_row[2]);
    int price=std::stoi(csv_row[3]);

    //fill the intermediate output map
    if(output_map->find(stock_symbol) != output_map->end()){
      unsigned long time_gap = time_stamp - (*(*output_map)[stock_symbol])[0];
      (*(*output_map)[stock_symbol])[0] = time_stamp;
      if(time_gap > (*(*output_map)[stock_symbol])[1])
        (*(*output_map)[stock_symbol])[1] = time_gap;
      (*(*output_map)[stock_symbol])[2] = share+(*(*output_map)[stock_symbol])[2];
      (*(*output_map)[stock_symbol])[3] = (*(*output_map)[stock_symbol])[3] + price*share;
      if(price > (*(*output_map)[stock_symbol])[4])
        (*(*output_map)[stock_symbol])[4] = price;
    }else{
      std::vector<unsigned long> *val = new std::vector<unsigned long>();
      val->push_back(time_stamp);
      val->push_back(0);
      val->push_back(share);
      val->push_back(price*share);
      val->push_back(price);
      (*output_map)[stock_symbol] = val;
    }
  }
}



//main function start
int main(){

  //Create an input filestream
  std::fstream fin;
  fin.open("input.csv", ios::in);

  //Make sure file is opened
  if(!fin.is_open()) throw std::runtime_error("Could not open input file");

  //store the intermediate output in a sorted map
  std::map<string, std::vector<unsigned long>*> output_map;
  readInput(&fin, &output_map);
  fin.close();

  //output to csv file
  std::fstream fout;
  fout.open("output.csv", ios::out);

  for(std::map<string, std::vector<unsigned long>*>::iterator itr = output_map.begin(); itr != output_map.end(); itr++){
    fout << itr->first << ",";
    fout << (*(itr->second))[1] << "," << (*(itr->second))[2] << "," << floor((*(itr->second))[3] / (*(itr->second))[2]) << "," << (*(itr->second))[4] << "\n";
    delete itr->second;
  }
  fout.close();

  return 0;
}
